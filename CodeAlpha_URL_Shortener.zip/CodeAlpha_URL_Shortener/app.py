"""
CodeAlpha - Task 1: Simple URL Shortener
A Flask backend that shortens long URLs, stores the mapping in SQLite,
and redirects short codes to their original URL.
"""

import string
import random
from datetime import datetime

from flask import Flask, request, jsonify, redirect, render_template, url_for, abort
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///urls.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db = SQLAlchemy(app)

CODE_LENGTH = 6
CODE_CHARS = string.ascii_letters + string.digits


# --------------------------------------------------------------------------
# Model
# --------------------------------------------------------------------------
class URLMap(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    short_code = db.Column(db.String(16), unique=True, nullable=False, index=True)
    original_url = db.Column(db.String(2048), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    clicks = db.Column(db.Integer, default=0)

    def to_dict(self):
        return {
            "id": self.id,
            "short_code": self.short_code,
            "original_url": self.original_url,
            "short_url": url_for("redirect_short_url", short_code=self.short_code, _external=True),
            "created_at": self.created_at.isoformat(),
            "clicks": self.clicks,
        }


def generate_unique_code(length=CODE_LENGTH):
    """Generate a short code that doesn't already exist in the database."""
    while True:
        code = "".join(random.choices(CODE_CHARS, k=length))
        if not URLMap.query.filter_by(short_code=code).first():
            return code


# --------------------------------------------------------------------------
# API routes
# --------------------------------------------------------------------------
@app.route("/api/shorten", methods=["POST"])
def shorten_url():
    data = request.get_json(silent=True) or request.form

    long_url = (data.get("url") or "").strip()
    if not long_url:
        return jsonify({"error": "Field 'url' is required"}), 400

    if not (long_url.startswith("http://") or long_url.startswith("https://")):
        long_url = "https://" + long_url

    # Optional custom alias
    custom_code = (data.get("custom_code") or "").strip()
    if custom_code:
        if URLMap.query.filter_by(short_code=custom_code).first():
            return jsonify({"error": "Custom code already taken"}), 409
        code = custom_code
    else:
        # Reuse existing short code if this URL was already shortened
        existing = URLMap.query.filter_by(original_url=long_url).first()
        if existing:
            return jsonify(existing.to_dict()), 200
        code = generate_unique_code()

    entry = URLMap(short_code=code, original_url=long_url)
    db.session.add(entry)
    db.session.commit()

    return jsonify(entry.to_dict()), 201


@app.route("/api/urls", methods=["GET"])
def list_urls():
    urls = URLMap.query.order_by(URLMap.created_at.desc()).all()
    return jsonify([u.to_dict() for u in urls])


@app.route("/api/urls/<short_code>", methods=["GET"])
def get_url_info(short_code):
    entry = URLMap.query.filter_by(short_code=short_code).first()
    if not entry:
        return jsonify({"error": "Short code not found"}), 404
    return jsonify(entry.to_dict())


@app.route("/api/urls/<short_code>", methods=["DELETE"])
def delete_url(short_code):
    entry = URLMap.query.filter_by(short_code=short_code).first()
    if not entry:
        return jsonify({"error": "Short code not found"}), 404
    db.session.delete(entry)
    db.session.commit()
    return jsonify({"message": "Deleted"}), 200


# --------------------------------------------------------------------------
# Redirect route
# --------------------------------------------------------------------------
@app.route("/<short_code>", methods=["GET"])
def redirect_short_url(short_code):
    entry = URLMap.query.filter_by(short_code=short_code).first()
    if not entry:
        abort(404)
    entry.clicks += 1
    db.session.commit()
    return redirect(entry.original_url)


# --------------------------------------------------------------------------
# Basic frontend
# --------------------------------------------------------------------------
@app.route("/", methods=["GET"])
def index():
    return render_template("index.html")


@app.errorhandler(404)
def not_found(e):
    return jsonify({"error": "Not found"}), 404


if __name__ == "__main__":
    with app.app_context():
        db.create_all()
    app.run(debug=True, port=5000)
