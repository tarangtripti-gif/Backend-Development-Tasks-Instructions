# CodeAlpha_URL_Shortener

A simple URL Shortener backend built with **Flask** and **SQLite**, developed as part of the **CodeAlpha Backend Development Internship (Task 1)**.

## Features

- Generate a unique short code for any long URL
- Redirect short URLs to their original destination
- Track click counts per short URL
- Optional custom alias support
- List, view, and delete shortened URLs via API
- Minimal frontend to shorten URLs and view recent links

## Tech Stack

- Python 3
- Flask
- Flask-SQLAlchemy
- SQLite

## Project Structure

```
CodeAlpha_URL_Shortener/
├── app.py              # Main Flask application
├── requirements.txt    # Python dependencies
├── templates/
│   └── index.html      # Basic frontend
└── urls.db              # SQLite database (auto-created on first run)
```

## Setup & Run

```bash
# 1. Clone the repo
git clone https://github.com/<your-username>/CodeAlpha_URL_Shortener.git
cd CodeAlpha_URL_Shortener

# 2. Create a virtual environment (recommended)
python -m venv venv
source venv/bin/activate   # On Windows: venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Run the app
python app.py
```

The app runs at `http://127.0.0.1:5000`.

## API Endpoints

| Method | Endpoint               | Description                          |
|--------|-------------------------|---------------------------------------|
| POST   | `/api/shorten`          | Create a short URL. Body: `{"url": "https://example.com", "custom_code": "optional"}` |
| GET    | `/api/urls`              | List all shortened URLs |
| GET    | `/api/urls/<short_code>` | Get details of a specific short URL |
| DELETE | `/api/urls/<short_code>` | Delete a short URL |
| GET    | `/<short_code>`          | Redirects to the original long URL |

### Example

```bash
curl -X POST http://127.0.0.1:5000/api/shorten \
  -H "Content-Type: application/json" \
  -d '{"url": "https://www.codealpha.tech"}'
```

Response:
```json
{
  "id": 1,
  "short_code": "aZ3kP9",
  "original_url": "https://www.codealpha.tech",
  "short_url": "http://127.0.0.1:5000/aZ3kP9",
  "created_at": "2026-06-30T10:00:00",
  "clicks": 0
}
```

## Author

Built as part of the **CodeAlpha Backend Development Internship**.
