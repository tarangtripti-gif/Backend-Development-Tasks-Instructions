"""
CodeAlpha - Task 3: Restaurant Management System
A Flask backend handling menu items, tables, reservations, orders and
inventory, with automatic inventory deduction and table availability checks.
"""

from datetime import datetime

from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///restaurant.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db = SQLAlchemy(app)


# --------------------------------------------------------------------------
# Models
# --------------------------------------------------------------------------
class InventoryItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), unique=True, nullable=False)
    quantity = db.Column(db.Float, default=0)   # stock on hand
    unit = db.Column(db.String(20), default="pcs")
    low_stock_threshold = db.Column(db.Float, default=5)

    def to_dict(self):
        return {
            "id": self.id, "name": self.name, "quantity": self.quantity,
            "unit": self.unit, "low_stock": self.quantity <= self.low_stock_threshold,
        }


class MenuItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    description = db.Column(db.String(300), default="")
    price = db.Column(db.Float, nullable=False)
    available = db.Column(db.Boolean, default=True)

    # Recipe: which inventory items + quantities this menu item consumes
    ingredients = db.relationship("MenuIngredient", backref="menu_item", cascade="all, delete-orphan")

    def to_dict(self):
        return {
            "id": self.id, "name": self.name, "description": self.description,
            "price": self.price, "available": self.available,
            "ingredients": [
                {"inventory_item_id": i.inventory_item_id, "name": i.inventory_item.name, "qty_used": i.qty_used}
                for i in self.ingredients
            ],
        }


class MenuIngredient(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    menu_item_id = db.Column(db.Integer, db.ForeignKey("menu_item.id"), nullable=False)
    inventory_item_id = db.Column(db.Integer, db.ForeignKey("inventory_item.id"), nullable=False)
    qty_used = db.Column(db.Float, nullable=False)  # qty consumed per single menu item sold

    inventory_item = db.relationship("InventoryItem")


class Table(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    number = db.Column(db.Integer, unique=True, nullable=False)
    seats = db.Column(db.Integer, default=2)
    status = db.Column(db.String(20), default="available")  # available | reserved | occupied

    def to_dict(self):
        return {"id": self.id, "number": self.number, "seats": self.seats, "status": self.status}


class Reservation(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    table_id = db.Column(db.Integer, db.ForeignKey("table.id"), nullable=False)
    customer_name = db.Column(db.String(120), nullable=False)
    party_size = db.Column(db.Integer, default=1)
    reservation_time = db.Column(db.DateTime, nullable=False)
    status = db.Column(db.String(20), default="booked")  # booked | cancelled | completed

    table = db.relationship("Table")

    def to_dict(self):
        return {
            "id": self.id, "table_id": self.table_id, "table_number": self.table.number,
            "customer_name": self.customer_name, "party_size": self.party_size,
            "reservation_time": self.reservation_time.isoformat(), "status": self.status,
        }


class Order(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    table_id = db.Column(db.Integer, db.ForeignKey("table.id"), nullable=True)
    status = db.Column(db.String(20), default="pending")  # pending | preparing | served | paid | cancelled
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    items = db.relationship("OrderItem", backref="order", cascade="all, delete-orphan")
    table = db.relationship("Table")

    def total(self):
        return round(sum(i.quantity * i.unit_price for i in self.items), 2)

    def to_dict(self):
        return {
            "id": self.id, "table_id": self.table_id, "status": self.status,
            "created_at": self.created_at.isoformat(), "total": self.total(),
            "items": [
                {"menu_item_id": i.menu_item_id, "name": i.menu_item.name,
                 "quantity": i.quantity, "unit_price": i.unit_price}
                for i in self.items
            ],
        }


class OrderItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey("order.id"), nullable=False)
    menu_item_id = db.Column(db.Integer, db.ForeignKey("menu_item.id"), nullable=False)
    quantity = db.Column(db.Integer, default=1)
    unit_price = db.Column(db.Float, nullable=False)

    menu_item = db.relationship("MenuItem")


# --------------------------------------------------------------------------
# Menu routes
# --------------------------------------------------------------------------
@app.route("/api/menu", methods=["POST"])
def create_menu_item():
    data = request.get_json(silent=True) or {}
    if not data.get("name") or data.get("price") is None:
        return jsonify({"error": "name and price are required"}), 400

    item = MenuItem(name=data["name"], description=data.get("description", ""), price=float(data["price"]))
    db.session.add(item)
    db.session.flush()

    for ing in data.get("ingredients", []):
        db.session.add(MenuIngredient(
            menu_item_id=item.id,
            inventory_item_id=ing["inventory_item_id"],
            qty_used=ing["qty_used"],
        ))
    db.session.commit()
    return jsonify(item.to_dict()), 201


@app.route("/api/menu", methods=["GET"])
def list_menu():
    return jsonify([m.to_dict() for m in MenuItem.query.all()])


@app.route("/api/menu/<int:item_id>", methods=["PUT"])
def update_menu_item(item_id):
    item = MenuItem.query.get(item_id)
    if not item:
        return jsonify({"error": "Menu item not found"}), 404
    data = request.get_json(silent=True) or {}
    for field in ("name", "description", "price", "available"):
        if field in data:
            setattr(item, field, data[field])
    db.session.commit()
    return jsonify(item.to_dict())


# --------------------------------------------------------------------------
# Inventory routes
# --------------------------------------------------------------------------
@app.route("/api/inventory", methods=["POST"])
def create_inventory_item():
    data = request.get_json(silent=True) or {}
    if not data.get("name"):
        return jsonify({"error": "name is required"}), 400
    item = InventoryItem(
        name=data["name"], quantity=float(data.get("quantity", 0)),
        unit=data.get("unit", "pcs"), low_stock_threshold=float(data.get("low_stock_threshold", 5)),
    )
    db.session.add(item)
    db.session.commit()
    return jsonify(item.to_dict()), 201


@app.route("/api/inventory", methods=["GET"])
def list_inventory():
    return jsonify([i.to_dict() for i in InventoryItem.query.all()])


@app.route("/api/inventory/<int:item_id>/restock", methods=["POST"])
def restock_inventory(item_id):
    item = InventoryItem.query.get(item_id)
    if not item:
        return jsonify({"error": "Inventory item not found"}), 404
    data = request.get_json(silent=True) or {}
    item.quantity += float(data.get("quantity", 0))
    db.session.commit()
    return jsonify(item.to_dict())


@app.route("/api/inventory/alerts", methods=["GET"])
def low_stock_alerts():
    items = InventoryItem.query.filter(InventoryItem.quantity <= InventoryItem.low_stock_threshold).all()
    return jsonify([i.to_dict() for i in items])


# --------------------------------------------------------------------------
# Table & reservation routes
# --------------------------------------------------------------------------
@app.route("/api/tables", methods=["POST"])
def create_table():
    data = request.get_json(silent=True) or {}
    if data.get("number") is None:
        return jsonify({"error": "number is required"}), 400
    table = Table(number=int(data["number"]), seats=int(data.get("seats", 2)))
    db.session.add(table)
    db.session.commit()
    return jsonify(table.to_dict()), 201


@app.route("/api/tables", methods=["GET"])
def list_tables():
    return jsonify([t.to_dict() for t in Table.query.all()])


@app.route("/api/reservations", methods=["POST"])
def create_reservation():
    data = request.get_json(silent=True) or {}
    table = Table.query.get(data.get("table_id"))
    if not table:
        return jsonify({"error": "Valid table_id is required"}), 400
    if table.status != "available":
        return jsonify({"error": f"Table {table.number} is not available"}), 409
    try:
        res_time = datetime.fromisoformat(data["reservation_time"])
    except (KeyError, ValueError):
        return jsonify({"error": "Valid ISO 'reservation_time' is required"}), 400

    reservation = Reservation(
        table_id=table.id, customer_name=data.get("customer_name", "Guest"),
        party_size=int(data.get("party_size", 1)), reservation_time=res_time,
    )
    table.status = "reserved"
    db.session.add(reservation)
    db.session.commit()
    return jsonify(reservation.to_dict()), 201


@app.route("/api/reservations/<int:res_id>/cancel", methods=["POST"])
def cancel_reservation(res_id):
    reservation = Reservation.query.get(res_id)
    if not reservation:
        return jsonify({"error": "Reservation not found"}), 404
    reservation.status = "cancelled"
    reservation.table.status = "available"
    db.session.commit()
    return jsonify(reservation.to_dict())


@app.route("/api/reservations", methods=["GET"])
def list_reservations():
    return jsonify([r.to_dict() for r in Reservation.query.all()])


# --------------------------------------------------------------------------
# Order routes (with inventory auto-update)
# --------------------------------------------------------------------------
@app.route("/api/orders", methods=["POST"])
def create_order():
    data = request.get_json(silent=True) or {}
    items_data = data.get("items", [])
    if not items_data:
        return jsonify({"error": "At least one item is required"}), 400

    table_id = data.get("table_id")
    if table_id:
        table = Table.query.get(table_id)
        if not table:
            return jsonify({"error": "Invalid table_id"}), 400
        table.status = "occupied"

    # Pre-check menu availability & inventory sufficiency
    for entry in items_data:
        menu_item = MenuItem.query.get(entry.get("menu_item_id"))
        if not menu_item or not menu_item.available:
            return jsonify({"error": f"Menu item {entry.get('menu_item_id')} unavailable"}), 400
        qty = int(entry.get("quantity", 1))
        for ing in menu_item.ingredients:
            needed = ing.qty_used * qty
            if ing.inventory_item.quantity < needed:
                return jsonify({"error": f"Insufficient stock for '{ing.inventory_item.name}'"}), 409

    order = Order(table_id=table_id, status="pending")
    db.session.add(order)
    db.session.flush()

    for entry in items_data:
        menu_item = MenuItem.query.get(entry["menu_item_id"])
        qty = int(entry.get("quantity", 1))
        db.session.add(OrderItem(order_id=order.id, menu_item_id=menu_item.id, quantity=qty, unit_price=menu_item.price))
        # Auto-deduct inventory
        for ing in menu_item.ingredients:
            ing.inventory_item.quantity -= ing.qty_used * qty

    db.session.commit()
    return jsonify(order.to_dict()), 201


@app.route("/api/orders/<int:order_id>", methods=["GET"])
def get_order(order_id):
    order = Order.query.get(order_id)
    if not order:
        return jsonify({"error": "Order not found"}), 404
    return jsonify(order.to_dict())


@app.route("/api/orders/<int:order_id>/status", methods=["PUT"])
def update_order_status(order_id):
    order = Order.query.get(order_id)
    if not order:
        return jsonify({"error": "Order not found"}), 404
    data = request.get_json(silent=True) or {}
    status = data.get("status")
    if status not in ("pending", "preparing", "served", "paid", "cancelled"):
        return jsonify({"error": "Invalid status"}), 400
    order.status = status
    if status == "paid" and order.table_id:
        order.table.status = "available"
    db.session.commit()
    return jsonify(order.to_dict())


@app.route("/api/orders", methods=["GET"])
def list_orders():
    return jsonify([o.to_dict() for o in Order.query.order_by(Order.created_at.desc()).all()])


# --------------------------------------------------------------------------
# Reporting
# --------------------------------------------------------------------------
@app.route("/api/reports/daily-sales", methods=["GET"])
def daily_sales():
    date_str = request.args.get("date")
    target_date = datetime.fromisoformat(date_str).date() if date_str else datetime.utcnow().date()
    orders = Order.query.filter(Order.status == "paid").all()
    todays = [o for o in orders if o.created_at.date() == target_date]
    return jsonify({
        "date": target_date.isoformat(),
        "orders_count": len(todays),
        "total_sales": round(sum(o.total() for o in todays), 2),
    })


@app.route("/", methods=["GET"])
def index():
    return jsonify({"message": "Restaurant Management System API is running"})


if __name__ == "__main__":
    with app.app_context():
        db.create_all()
    app.run(debug=True, port=5002)
