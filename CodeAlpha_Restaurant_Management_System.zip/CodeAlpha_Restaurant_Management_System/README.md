# CodeAlpha_Restaurant_Management_System

A backend system for managing restaurant orders, tables, reservations, menu and inventory, built with **Flask** and **SQLite**, developed as part of the **CodeAlpha Backend Development Internship (Task 3)**.

## Features

- Menu management with optional recipe (ingredient) linkage to inventory
- Inventory tracking with auto-deduction on order placement and low-stock alerts
- Table management with status (available / reserved / occupied)
- Reservations with availability checks
- Order placement with automatic inventory updates and stock-sufficiency checks
- Order status workflow: pending → preparing → served → paid
- Daily sales reporting

## Tech Stack

- Python 3
- Flask
- Flask-SQLAlchemy
- SQLite

## Project Structure

```
CodeAlpha_Restaurant_Management_System/
├── app.py              # Main Flask application (models + routes)
├── requirements.txt
└── restaurant.db        # SQLite database (auto-created on first run)
```

## Setup & Run

```bash
git clone https://github.com/<your-username>/CodeAlpha_Restaurant_Management_System.git
cd CodeAlpha_Restaurant_Management_System

python -m venv venv
source venv/bin/activate   # On Windows: venv\Scripts\activate

pip install -r requirements.txt
python app.py
```

The API runs at `http://127.0.0.1:5002`.

## API Endpoints

### Menu
| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/menu` | Create a menu item (optionally with `ingredients`) |
| GET | `/api/menu` | List menu items |
| PUT | `/api/menu/<id>` | Update a menu item |

### Inventory
| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/inventory` | Add an inventory item |
| GET | `/api/inventory` | List inventory |
| POST | `/api/inventory/<id>/restock` | Add stock quantity |
| GET | `/api/inventory/alerts` | List items at/below low-stock threshold |

### Tables & Reservations
| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/tables` | Add a table |
| GET | `/api/tables` | List tables |
| POST | `/api/reservations` | Reserve a table |
| POST | `/api/reservations/<id>/cancel` | Cancel a reservation |
| GET | `/api/reservations` | List reservations |

### Orders
| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/orders` | Place an order (auto-deducts inventory) |
| GET | `/api/orders` | List all orders |
| GET | `/api/orders/<id>` | Get order details |
| PUT | `/api/orders/<id>/status` | Update order status |

### Reports
| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/reports/daily-sales?date=YYYY-MM-DD` | Daily sales total (defaults to today) |

### Example: place an order

```bash
curl -X POST http://127.0.0.1:5002/api/orders \
  -H "Content-Type: application/json" \
  -d '{"table_id": 1, "items": [{"menu_item_id": 1, "quantity": 2}]}'
```

## Author

Built as part of the **CodeAlpha Backend Development Internship**.
