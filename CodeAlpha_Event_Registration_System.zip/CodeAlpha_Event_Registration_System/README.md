# CodeAlpha_Event_Registration_System

A backend system for managing events and user registrations, built with **Flask** and **SQLite**, developed as part of the **CodeAlpha Backend Development Internship (Task 2)**.

## Features

- User registration & login (password hashing with Werkzeug)
- Create, update, list, view, and delete events
- Register/cancel registration for an event, linked to users
- Capacity limits per event (auto-rejects once full)
- View a user's registration history

## Tech Stack

- Python 3
- Flask
- Flask-SQLAlchemy
- SQLite

## Project Structure

```
CodeAlpha_Event_Registration_System/
├── app.py              # Main Flask application (models + routes)
├── requirements.txt
└── events.db            # SQLite database (auto-created on first run)
```

## Setup & Run

```bash
git clone https://github.com/<your-username>/CodeAlpha_Event_Registration_System.git
cd CodeAlpha_Event_Registration_System

python -m venv venv
source venv/bin/activate   # On Windows: venv\Scripts\activate

pip install -r requirements.txt
python app.py
```

The API runs at `http://127.0.0.1:5001`.

## API Endpoints

| Method | Endpoint                              | Description |
|--------|-----------------------------------------|--------------|
| POST   | `/api/users/register`                  | Register a new user |
| POST   | `/api/users/login`                     | Login with email/password |
| POST   | `/api/events`                          | Create an event |
| GET    | `/api/events`                          | List all events |
| GET    | `/api/events/<id>`                     | Get event details + registrations |
| PUT    | `/api/events/<id>`                     | Update an event |
| DELETE | `/api/events/<id>`                     | Delete an event |
| POST   | `/api/events/<id>/register`            | Register a user for an event |
| POST   | `/api/events/<id>/cancel`              | Cancel a user's registration |
| GET    | `/api/users/<id>/registrations`        | List a user's registrations |

### Example: create an event

```bash
curl -X POST http://127.0.0.1:5001/api/events \
  -H "Content-Type: application/json" \
  -d '{"title": "Tech Meetup", "date": "2026-08-15T10:00:00", "location": "Jaipur", "capacity": 50}'
```

### Example: register a user for an event

```bash
curl -X POST http://127.0.0.1:5001/api/events/1/register \
  -H "Content-Type: application/json" \
  -d '{"user_id": 1}'
```

## Author

Built as part of the **CodeAlpha Backend Development Internship**.
