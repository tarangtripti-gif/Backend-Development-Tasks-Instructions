"""
CodeAlpha - Task 2: Event Registration System
A Flask backend to manage events and user registrations, backed by SQLite.
"""

from datetime import datetime

from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///events.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db = SQLAlchemy(app)


# --------------------------------------------------------------------------
# Models
# --------------------------------------------------------------------------
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    is_organizer = db.Column(db.Boolean, default=False)

    registrations = db.relationship("Registration", backref="user", cascade="all, delete-orphan")

    def to_dict(self):
        return {"id": self.id, "name": self.name, "email": self.email, "is_organizer": self.is_organizer}


class Event(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, default="")
    location = db.Column(db.String(200), default="")
    date = db.Column(db.DateTime, nullable=False)
    capacity = db.Column(db.Integer, default=0)  # 0 = unlimited
    organizer_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=True)

    registrations = db.relationship("Registration", backref="event", cascade="all, delete-orphan")

    def to_dict(self, include_registrations=False):
        data = {
            "id": self.id,
            "title": self.title,
            "description": self.description,
            "location": self.location,
            "date": self.date.isoformat(),
            "capacity": self.capacity,
            "registered_count": len([r for r in self.registrations if r.status == "confirmed"]),
            "organizer_id": self.organizer_id,
        }
        if include_registrations:
            data["registrations"] = [r.to_dict() for r in self.registrations]
        return data


class Registration(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    event_id = db.Column(db.Integer, db.ForeignKey("event.id"), nullable=False)
    status = db.Column(db.String(20), default="confirmed")  # confirmed | cancelled
    registered_at = db.Column(db.DateTime, default=datetime.utcnow)

    __table_args__ = (db.UniqueConstraint("user_id", "event_id", name="uq_user_event"),)

    def to_dict(self):
        return {
            "id": self.id,
            "user_id": self.user_id,
            "user_name": self.user.name if self.user else None,
            "event_id": self.event_id,
            "event_title": self.event.title if self.event else None,
            "status": self.status,
            "registered_at": self.registered_at.isoformat(),
        }


# --------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------
def parse_date(value):
    try:
        return datetime.fromisoformat(value)
    except (TypeError, ValueError):
        return None


# --------------------------------------------------------------------------
# User routes (simple auth, no JWT for brevity)
# --------------------------------------------------------------------------
@app.route("/api/users/register", methods=["POST"])
def register_user():
    data = request.get_json(silent=True) or {}
    name, email, password = data.get("name"), data.get("email"), data.get("password")
    if not all([name, email, password]):
        return jsonify({"error": "name, email and password are required"}), 400
    if User.query.filter_by(email=email).first():
        return jsonify({"error": "Email already registered"}), 409

    user = User(
        name=name,
        email=email,
        password_hash=generate_password_hash(password),
        is_organizer=bool(data.get("is_organizer", False)),
    )
    db.session.add(user)
    db.session.commit()
    return jsonify(user.to_dict()), 201


@app.route("/api/users/login", methods=["POST"])
def login_user():
    data = request.get_json(silent=True) or {}
    user = User.query.filter_by(email=data.get("email")).first()
    if not user or not check_password_hash(user.password_hash, data.get("password", "")):
        return jsonify({"error": "Invalid credentials"}), 401
    return jsonify(user.to_dict()), 200


# --------------------------------------------------------------------------
# Event routes
# --------------------------------------------------------------------------
@app.route("/api/events", methods=["POST"])
def create_event():
    data = request.get_json(silent=True) or {}
    title = data.get("title")
    date = parse_date(data.get("date"))
    if not title or not date:
        return jsonify({"error": "title and a valid ISO 'date' are required"}), 400

    event = Event(
        title=title,
        description=data.get("description", ""),
        location=data.get("location", ""),
        date=date,
        capacity=int(data.get("capacity", 0) or 0),
        organizer_id=data.get("organizer_id"),
    )
    db.session.add(event)
    db.session.commit()
    return jsonify(event.to_dict()), 201


@app.route("/api/events", methods=["GET"])
def list_events():
    events = Event.query.order_by(Event.date.asc()).all()
    return jsonify([e.to_dict() for e in events])


@app.route("/api/events/<int:event_id>", methods=["GET"])
def get_event(event_id):
    event = Event.query.get(event_id)
    if not event:
        return jsonify({"error": "Event not found"}), 404
    return jsonify(event.to_dict(include_registrations=True))


@app.route("/api/events/<int:event_id>", methods=["PUT"])
def update_event(event_id):
    event = Event.query.get(event_id)
    if not event:
        return jsonify({"error": "Event not found"}), 404
    data = request.get_json(silent=True) or {}
    for field in ("title", "description", "location", "capacity"):
        if field in data:
            setattr(event, field, data[field])
    if "date" in data:
        new_date = parse_date(data["date"])
        if new_date:
            event.date = new_date
    db.session.commit()
    return jsonify(event.to_dict())


@app.route("/api/events/<int:event_id>", methods=["DELETE"])
def delete_event(event_id):
    event = Event.query.get(event_id)
    if not event:
        return jsonify({"error": "Event not found"}), 404
    db.session.delete(event)
    db.session.commit()
    return jsonify({"message": "Event deleted"})


# --------------------------------------------------------------------------
# Registration routes
# --------------------------------------------------------------------------
@app.route("/api/events/<int:event_id>/register", methods=["POST"])
def register_for_event(event_id):
    data = request.get_json(silent=True) or {}
    user_id = data.get("user_id")

    event = Event.query.get(event_id)
    user = User.query.get(user_id) if user_id else None
    if not event or not user:
        return jsonify({"error": "Valid event_id and user_id are required"}), 400

    existing = Registration.query.filter_by(user_id=user_id, event_id=event_id).first()
    if existing:
        if existing.status == "confirmed":
            return jsonify({"error": "User already registered"}), 409
        existing.status = "confirmed"
        existing.registered_at = datetime.utcnow()
        db.session.commit()
        return jsonify(existing.to_dict()), 200

    if event.capacity:
        confirmed_count = Registration.query.filter_by(event_id=event_id, status="confirmed").count()
        if confirmed_count >= event.capacity:
            return jsonify({"error": "Event is fully booked"}), 409

    reg = Registration(user_id=user_id, event_id=event_id)
    db.session.add(reg)
    db.session.commit()
    return jsonify(reg.to_dict()), 201


@app.route("/api/events/<int:event_id>/cancel", methods=["POST"])
def cancel_registration(event_id):
    data = request.get_json(silent=True) or {}
    user_id = data.get("user_id")
    reg = Registration.query.filter_by(user_id=user_id, event_id=event_id).first()
    if not reg:
        return jsonify({"error": "Registration not found"}), 404
    reg.status = "cancelled"
    db.session.commit()
    return jsonify(reg.to_dict())


@app.route("/api/users/<int:user_id>/registrations", methods=["GET"])
def user_registrations(user_id):
    regs = Registration.query.filter_by(user_id=user_id).all()
    return jsonify([r.to_dict() for r in regs])


@app.route("/", methods=["GET"])
def index():
    return jsonify({
        "message": "Event Registration System API",
        "endpoints": [
            "POST /api/users/register", "POST /api/users/login",
            "POST /api/events", "GET /api/events", "GET /api/events/<id>",
            "PUT /api/events/<id>", "DELETE /api/events/<id>",
            "POST /api/events/<id>/register", "POST /api/events/<id>/cancel",
            "GET /api/users/<id>/registrations",
        ],
    })


if __name__ == "__main__":
    with app.app_context():
        db.create_all()
    app.run(debug=True, port=5001)
